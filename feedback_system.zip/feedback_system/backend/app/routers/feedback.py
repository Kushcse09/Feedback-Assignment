from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from pydantic import BaseModel
from datetime import datetime

from ..database import get_db
from ..models import Feedback, FeedbackAcknowledgment, User, SentimentType, UserRole
from .auth import get_current_user

router = APIRouter()

class FeedbackCreate(BaseModel):
    employee_id: int
    strengths: str
    improvements: str
    sentiment: str
    tags: str = ""

class FeedbackUpdate(BaseModel):
    strengths: str = None
    improvements: str = None
    sentiment: str = None
    tags: str = None

class FeedbackResponse(BaseModel):
    id: int
    manager_id: int
    employee_id: int
    strengths: str
    improvements: str
    sentiment: str
    tags: str
    created_at: datetime
    updated_at: datetime
    manager_name: str
    employee_name: str
    is_acknowledged: bool = False
    
    class Config:
        from_attributes = True

@router.post("/", response_model=FeedbackResponse)
def create_feedback(
    feedback: FeedbackCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    if current_user.role != UserRole.MANAGER:
        raise HTTPException(status_code=403, detail="Only managers can create feedback")
    
    # Verify employee is in manager's team
    employee = db.query(User).filter(User.id == feedback.employee_id).first()
    if not employee or employee.manager_id != current_user.id:
        raise HTTPException(status_code=403, detail="Employee not in your team")
    
    db_feedback = Feedback(
        manager_id=current_user.id,
        employee_id=feedback.employee_id,
        strengths=feedback.strengths,
        improvements=feedback.improvements,
        sentiment=SentimentType(feedback.sentiment),
        tags=feedback.tags
    )
    
    db.add(db_feedback)
    db.commit()
    db.refresh(db_feedback)
    
    # Add manager and employee names
    result = FeedbackResponse(
        **db_feedback.__dict__,
        manager_name=current_user.name,
        employee_name=employee.name
    )
    
    return result

@router.get("/", response_model=List[FeedbackResponse])
def get_feedback(
    db: Session = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    if current_user.role == UserRole.MANAGER:
        # Manager sees feedback for their team
        feedback_list = db.query(Feedback).filter(Feedback.manager_id == current_user.id).all()
    else:
        # Employee sees their own feedback
        feedback_list = db.query(Feedback).filter(Feedback.employee_id == current_user.id).all()
    
    result = []
    for fb in feedback_list:
        manager = db.query(User).filter(User.id == fb.manager_id).first()
        employee = db.query(User).filter(User.id == fb.employee_id).first()
        
        # Check if acknowledged
        ack = db.query(FeedbackAcknowledgment).filter(
            FeedbackAcknowledgment.feedback_id == fb.id,
            FeedbackAcknowledgment.employee_id == fb.employee_id
        ).first()
        
        result.append(FeedbackResponse(
            **fb.__dict__,
            manager_name=manager.name,
            employee_name=employee.name,
            is_acknowledged=bool(ack)
        ))
    
    return result

@router.put("/{feedback_id}", response_model=FeedbackResponse)
def update_feedback(
    feedback_id: int,
    feedback_update: FeedbackUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if not feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")
    
    if feedback.manager_id != current_user.id:
        raise HTTPException(status_code=403, detail="Can only edit your own feedback")
    
    # Update fields
    if feedback_update.strengths is not None:
        feedback.strengths = feedback_update.strengths
    if feedback_update.improvements is not None:
        feedback.improvements = feedback_update.improvements
    if feedback_update.sentiment is not None:
        feedback.sentiment = SentimentType(feedback_update.sentiment)
    if feedback_update.tags is not None:
        feedback.tags = feedback_update.tags
    
    feedback.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(feedback)
    
    manager = db.query(User).filter(User.id == feedback.manager_id).first()
    employee = db.query(User).filter(User.id == feedback.employee_id).first()
    
    return FeedbackResponse(
        **feedback.__dict__,
        manager_name=manager.name,
        employee_name=employee.name
    )

@router.post("/{feedback_id}/acknowledge")
def acknowledge_feedback(
    feedback_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    feedback = db.query(Feedback).filter(Feedback.id == feedback_id).first()
    if not feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")
    
    if feedback.employee_id != current_user.id:
        raise HTTPException(status_code=403, detail="Can only acknowledge your own feedback")
    
    # Check if already acknowledged
    existing_ack = db.query(FeedbackAcknowledgment).filter(
        FeedbackAcknowledgment.feedback_id == feedback_id,
        FeedbackAcknowledgment.employee_id == current_user.id
    ).first()
    
    if existing_ack:
        raise HTTPException(status_code=400, detail="Feedback already acknowledged")
    
    acknowledgment = FeedbackAcknowledgment(
        feedback_id=feedback_id,
        employee_id=current_user.id
    )
    
    db.add(acknowledgment)
    db.commit()
    
    return {"message": "Feedback acknowledged successfully"}
