from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from ..database import get_db
from ..models import User, UserRole
from .auth import get_current_user, UserResponse

router = APIRouter()

@router.get("/me", response_model=UserResponse)
def get_current_user_info(current_user: User = Depends(get_current_user)):
    return current_user

@router.get("/team", response_model=List[UserResponse])
def get_team_members(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if current_user.role != UserRole.MANAGER:
        return []
    
    team_members = db.query(User).filter(User.manager_id == current_user.id).all()
    return team_members

@router.get("/managers", response_model=List[UserResponse])
def get_managers(db: Session = Depends(get_db)):
    managers = db.query(User).filter(User.role == UserRole.MANAGER).all()
    return managers
