import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  Grid,
  Chip,
  AppBar,
  Toolbar,
  IconButton
} from '@mui/material';
import { Logout, Add, Edit } from '@mui/icons-material';
import { feedbackAPI, usersAPI } from '../services/api';

function ManagerDashboard({ user, onLogout }) {
  const [feedback, setFeedback] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingFeedback, setEditingFeedback] = useState(null);
  const [formData, setFormData] = useState({
    employee_id: '',
    strengths: '',
    improvements: '',
    sentiment: 'positive',
    tags: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [feedbackRes, teamRes] = await Promise.all([
        feedbackAPI.getFeedback(),
        usersAPI.getTeamMembers()
      ]);
      setFeedback(feedbackRes.data);
      setTeamMembers(teamRes.data);
    } catch (err) {
      console.error('Failed to load data:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingFeedback) {
        await feedbackAPI.updateFeedback(editingFeedback.id, formData);
      } else {
        await feedbackAPI.createFeedback(formData);
      }
      setOpenDialog(false);
      setEditingFeedback(null);
      setFormData({
        employee_id: '',
        strengths: '',
        improvements: '',
        sentiment: 'positive',
        tags: ''
      });
      loadData();
    } catch (err) {
      console.error('Failed to save feedback:', err);
    }
  };

  const handleEdit = (feedbackItem) => {
    setEditingFeedback(feedbackItem);
    setFormData({
      employee_id: feedbackItem.employee_id,
      strengths: feedbackItem.strengths,
      improvements: feedbackItem.improvements,
      sentiment: feedbackItem.sentiment,
      tags: feedbackItem.tags
    });
    setOpenDialog(true);
  };

  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'success';
      case 'negative': return 'error';
      default: return 'default';
    }
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Manager Dashboard - {user.name}
          </Typography>
          <IconButton color="inherit" onClick={onLogout}>
            <Logout />
          </IconButton>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom>Team Overview</Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Team Size</Typography>
                  <Typography variant="h3" color="primary">
                    {teamMembers.length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Total Feedback</Typography>
                  <Typography variant="h3" color="primary">
                    {feedback.length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6">Acknowledged</Typography>
                  <Typography variant="h3" color="success.main">
                    {feedback.filter(f => f.is_acknowledged).length}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Box>

        <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h5">Feedback History</Typography>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => setOpenDialog(true)}
          >
            Give Feedback
          </Button>
        </Box>

        <Grid container spacing={3}>
          {feedback.map((item) => (
            <Grid item xs={12} md={6} key={item.id}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Typography variant="h6">{item.employee_name}</Typography>
                    <Box>
                      <Chip 
                        label={item.sentiment} 
                        color={getSentimentColor(item.sentiment)}
                        size="small"
                        sx={{ mr: 1 }}
                      />
                      {item.is_acknowledged && (
                        <Chip label="Acknowledged" color="success" size="small" />
                      )}
                    </Box>
                  </Box>
                  
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    <strong>Strengths:</strong> {item.strengths}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    <strong>Improvements:</strong> {item.improvements}
                  </Typography>
                  
                  {item.tags && (
                    <Box sx={{ mt: 1 }}>
                      {item.tags.split(',').map((tag, index) => (
                        <Chip key={index} label={tag.trim()} size="small" sx={{ mr: 1 }} />
                      ))}
                    </Box>
                  )}
                  
                  <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="caption" color="text.secondary">
                      {new Date(item.created_at).toLocaleDateString()}
                    </Typography>
                    <IconButton size="small" onClick={() => handleEdit(item)}>
                      <Edit />
                    </IconButton>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
          <form onSubmit={handleSubmit}>
            <DialogTitle>
              {editingFeedback ? 'Edit Feedback' : 'Give Feedback'}
            </DialogTitle>
            <DialogContent>
              <FormControl fullWidth margin="normal">
                <InputLabel>Team Member</InputLabel>
                <Select
                  value={formData.employee_id}
                  onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                  required
                  disabled={!!editingFeedback}
                >
                  {teamMembers.map((member) => (
                    <MenuItem key={member.id} value={member.id}>
                      {member.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <TextField
                fullWidth
                label="Strengths"
                multiline
                rows={4}
                value={formData.strengths}
                onChange={(e) => setFormData({ ...formData, strengths: e.target.value })}
                margin="normal"
                required
              />
              
              <TextField
                fullWidth
                label="Areas to Improve"
                multiline
                rows={4}
                value={formData.improvements}
                onChange={(e) => setFormData({ ...formData, improvements: e.target.value })}
                margin="normal"
                required
              />
              
              <FormControl fullWidth margin="normal">
                <InputLabel>Overall Sentiment</InputLabel>
                <Select
                  value={formData.sentiment}
                  onChange={(e) => setFormData({ ...formData, sentiment: e.target.value })}
                  required
                >
                  <MenuItem value="positive">Positive</MenuItem>
                  <MenuItem value="neutral">Neutral</MenuItem>
                  <MenuItem value="negative">Negative</MenuItem>
                </Select>
              </FormControl>
              
              <TextField
                fullWidth
                label="Tags (comma-separated)"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                margin="normal"
                helperText="e.g., communication, leadership, technical"
              />
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
              <Button type="submit" variant="contained">
                {editingFeedback ? 'Update' : 'Submit'}
              </Button>
            </DialogActions>
          </form>
        </Dialog>
      </Container>
    </>
  );
}

export default ManagerDashboard;
