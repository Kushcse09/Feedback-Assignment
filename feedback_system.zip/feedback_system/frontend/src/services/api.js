import axios from 'axios';

const API_URL = 'http://localhost:8000';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth API
export const authAPI = {
  login: (email, password) => 
    api.post('/auth/login', { username: email, password }),
  
  register: (userData) => 
    api.post('/auth/register', userData),
  
  getCurrentUser: () => 
    api.get('/users/me'),
};

// Feedback API
export const feedbackAPI = {
  getFeedback: () => 
    api.get('/feedback/'),
  
  createFeedback: (feedback) => 
    api.post('/feedback/', feedback),
  
  updateFeedback: (id, feedback) => 
    api.put(`/feedback/${id}`, feedback),
  
  acknowledgeFeedback: (id) => 
    api.post(`/feedback/${id}/acknowledge`),
};

// Users API
export const usersAPI = {
  getTeamMembers: () => 
    api.get('/users/team'),
  
  getManagers: () => 
    api.get('/users/managers'),
};

export default api;
